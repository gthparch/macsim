/sbin/mark_app
./hello_world
/sbin/mark_app end
